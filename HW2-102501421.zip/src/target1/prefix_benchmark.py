"""HW2 target1. Run on the GPU server while SGLang is running.

Client TTFT: request submission to receipt of first generated token.
Client TPOT: (receipt of last token - receipt of first token)/(output tokens-1).
E2E: submission to receipt of SSE [DONE]. Percentiles: linear interpolation.
Throughput: successful requests or output tokens / measured group wall time.
Prefill accounting follows the assignment: sum(prompt_tokens-cached_tokens).
"""
import argparse
import asyncio
import csv
import importlib.metadata
import json
import platform
import random
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import aiohttp
from transformers import AutoTokenizer

PARAMS = dict(temperature=0, max_new_tokens=16, ignore_eos=True, sampling_seed=2026)


def save_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def percentile(values, q):
    values = sorted(values)
    x = (len(values) - 1) * q
    lo = int(x)
    hi = min(lo + 1, len(values) - 1)
    return values[lo] + (values[hi] - values[lo]) * (x - lo)


def workloads(model):
    tokenizer = AutoTokenizer.from_pretrained(model, local_files_only=True)
    tokens = tokenizer.encode(
        "This experiment measures prefix cache reuse in a language model. " * 500,
        add_special_tokens=False,
    )
    prefix = tokens[:2048]
    assert len(prefix) == 2048
    # Valid ordinary token IDs; distinct suffix starts prevent cross-request
    # sharing beyond the common prefix. Dispersed inputs differ only at token 0.
    assert all(0 <= t < tokenizer.vocab_size for t in range(1000, 1032))
    assert all(0 <= t < tokenizer.vocab_size for t in range(2000, 2032))
    assert prefix[0] not in range(2000, 2032)
    rng = random.Random(2026)
    groups = {"shared_prefix": [], "dispersed_prefix": []}
    for i in range(32):
        suffix = [1000 + i] + [rng.randrange(3000, 10000) for _ in range(63)]
        shared = prefix + suffix
        dispersed = [2000 + i] + shared[1:]
        assert len(shared) == len(dispersed) == 2112
        groups["shared_prefix"].append(shared)
        groups["dispersed_prefix"].append(dispersed)
    return prefix, groups


async def generate(session, base, ids, request_id, path):
    row = dict(request_id=request_id, success=False, http_status=None,
               prompt_tokens=None, completion_tokens=None, cached_tokens=None,
               prefill_tokens=None, ttft_ms=None, tpot_ms=None, e2e_ms=None,
               token_events=None, error="")
    events = []
    started = time.perf_counter()
    first = last = None
    count = 0
    final_meta = None
    done = False
    try:
        async with session.post(base + "/generate", json={
            "input_ids": ids, "sampling_params": PARAMS, "stream": True,
        }) as response:
            row["http_status"] = response.status
            if response.status != 200:
                raise RuntimeError((await response.text())[:2000])
            while True:
                raw = await response.content.readline()
                received = time.perf_counter()
                if not raw:
                    break
                line = raw.decode("utf-8").strip()
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    done = True
                    row["e2e_ms"] = (received - started) * 1000
                    break
                obj = json.loads(payload)
                events.append({"received_ms": (received-started)*1000, "data": obj})
                if "error" in obj:
                    raise RuntimeError(str(obj["error"]))
                meta = obj["meta_info"]
                new_count = int(meta["completion_tokens"])
                if new_count < count:
                    raise RuntimeError("Completion count decreased; investigate retraction")
                if new_count > count:
                    if new_count != count + 1:
                        raise RuntimeError("Stream grouped tokens; cannot measure first token accurately")
                    if first is None:
                        first = received
                    last = received
                    count = new_count
                if meta.get("finish_reason") is not None:
                    final_meta = meta
            if not done or final_meta is None:
                raise RuntimeError("Missing final metadata or [DONE]")
            row.update({k: int(final_meta[k]) for k in
                        ("prompt_tokens", "completion_tokens", "cached_tokens")})
            if row["prompt_tokens"] != len(ids) or row["completion_tokens"] != 16:
                raise RuntimeError("Input/output length does not match configuration")
            if not 0 <= row["cached_tokens"] <= len(ids):
                raise RuntimeError("Invalid cached_tokens")
            if count != 16 or first is None or last is None:
                raise RuntimeError("Incomplete token stream")
            row.update(success=True,
                       prefill_tokens=row["prompt_tokens"]-row["cached_tokens"],
                       ttft_ms=(first-started)*1000,
                       tpot_ms=(last-first)/15*1000,
                       token_events=count)
    except Exception as exc:
        row["error"] = f"{type(exc).__name__}: {exc}"
        if row["e2e_ms"] is None:
            row["e2e_ms"] = (time.perf_counter()-started)*1000
    if path is None:
        row["_events"] = events
    else:
        save_json(path, {"result": row, "events": events})
    return row


async def flush(session, base, path):
    # Called after all preceding streams finished. Server waits for idle and
    # confirms flush success with HTTP 200; failed flush aborts the experiment.
    async with session.post(base + "/flush_cache", params={"timeout": 30}) as r:
        body = await r.text()
        save_json(path, {"status": r.status, "body": body})
        if r.status != 200 or "Cache flushed." not in body:
            raise RuntimeError(f"Cache flush failed: HTTP {r.status}: {body}")


async def run_group(session, args, name, inputs, prefix, root):
    folder = root / "target1" / name
    folder.mkdir(parents=True)
    save_json(folder / "inputs.json", {"sampling_params": PARAMS, "input_ids": inputs})
    await flush(session, args.base, folder / "flush.json")
    if name == "shared_prefix":
        warm = await generate(session, args.base, prefix, "prefix_warmup", folder / "warmup.json")
        if not warm["success"]:
            raise RuntimeError(f"Prefix warmup failed: {warm}")
    semaphore = asyncio.Semaphore(8)

    async def send(i, ids):
        # Semaphore wait is outside request latency; all groups use the same
        # submission order and concurrency ceiling. No artificial arrival delay.
        async with semaphore:
            return await generate(session, args.base, ids, i+1, None)

    started = time.perf_counter()
    rows = await asyncio.gather(*(send(i, ids) for i, ids in enumerate(inputs)))
    elapsed = time.perf_counter()-started
    # Persist and print only after timing, so disk/terminal IO cannot delay
    # other requests or inflate the measured group duration.
    for row in rows:
        events = row.pop("_events")
        save_json(folder / f"request-{row['request_id']:02d}.json", {"result": row, "events": events})
        print(f"{name} {row['request_id']:02d}/32 success={row['success']} "
              f"cached={row['cached_tokens']} TTFT_ms={row['ttft_ms']} "
              f"error={row['error']}", flush=True)
    with (folder / "requests.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    good = [r for r in rows if r["success"]]
    summary = dict(group=name, successful_requests=len(good), total_requests=32,
                   success_rate=len(good)/32, wall_time_s=elapsed,
                   throughput_requests_s=len(good)/elapsed,
                   throughput_output_tokens_s=sum(r["completion_tokens"] for r in good)/elapsed,
                   prompt_tokens=sum(r["prompt_tokens"] for r in good),
                   cached_tokens=sum(r["cached_tokens"] for r in good),
                   actual_prefill_tokens=sum(r["prefill_tokens"] for r in good))
    summary["cache_hit_rate"] = (summary["cached_tokens"]/summary["prompt_tokens"]
                                 if good else None)
    for metric in ("ttft_ms", "tpot_ms", "e2e_ms"):
        for q, label in ((0.5, "p50"), (0.95, "p95")):
            summary[f"{metric}_{label}"] = percentile([r[metric] for r in good], q) if good else None
    save_json(folder / "summary.json", summary)
    return summary


async def main(args):
    root = Path(args.results) / datetime.now(timezone.utc).strftime("run-%Y%m%dT%H%M%S.%fZ")
    root.mkdir(parents=True)
    print(f"RESULTS: {root.resolve()}", flush=True)
    versions = {name: importlib.metadata.version(name) for name in ("sglang", "ray", "aiohttp", "transformers", "torch")}
    if versions["sglang"] != "0.5.14" or versions["ray"] != "2.56.0":
        raise RuntimeError(f"Wrong required versions: {versions}")
    gpu = subprocess.run(["nvidia-smi"], capture_output=True, text=True)
    (root / "nvidia-smi.txt").write_text(gpu.stdout + gpu.stderr, encoding="utf-8")
    save_json(root / "config.json", {"versions": versions, "python": platform.python_version(),
              "base": args.base, "model": args.model, "sampling_params": PARAMS,
              "requests_per_group": 32, "max_concurrency": 8, "prefix_length": 2048,
              "suffix_length": 64, "latency_definitions": __doc__,
              "group_order": ["dispersed_prefix", "shared_prefix"]})
    prefix, groups = workloads(args.model)
    save_json(root / "prefix.json", prefix)
    timeout = aiohttp.ClientTimeout(total=600)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(args.base + "/get_server_info") as r:
            (root / "server_info.json").write_text(await r.text(), encoding="utf-8")
            if r.status != 200:
                raise RuntimeError("Cannot obtain server configuration")
        warm = await generate(session, args.base, [100,101,102,103,104,105,106,107],
                              "service_warmup", root / "service_warmup.json")
        if not warm["success"]:
            raise RuntimeError(f"Service warmup failed: {warm}")
        summaries = []
        for name in ("dispersed_prefix", "shared_prefix"):
            summaries.append(await run_group(session, args, name, groups[name], prefix, root))
    with (root / "comparison.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)
    a, b = summaries
    passed = (a["successful_requests"] == b["successful_requests"] == 32
              and b["cache_hit_rate"] > a["cache_hit_rate"]
              and b["actual_prefill_tokens"] < a["actual_prefill_tokens"])
    save_json(root / "validation.json", {"assignment_checks_passed": passed})
    print(json.dumps(summaries, ensure_ascii=False, indent=2))
    print(f"ASSIGNMENT CHECKS: {'PASS' if passed else 'FAIL'}")
    print(f"RESULTS: {root.resolve()}")
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", default="http://127.0.0.1:30000")
    parser.add_argument("--model", default="/root/autodl-tmp/models/Qwen3-0.6B")
    parser.add_argument("--results", default="results")
    asyncio.run(main(parser.parse_args()))
